# README

## Ready

[二进制方式部署k8s集群 - 云+社区 - 腾讯云 (tencent.com)](https://cloud.tencent.com/developer/article/1671650)

```bash
wget https://dl.k8s.io/v1.12.6/kubernetes-server-linux-amd64.tar.gz
wget https://dl.k8s.io/v1.12.6/kubernetes-client-linux-amd64.tar.gz
wget https://dl.k8s.io/v1.12.6/kubernetes-node-linux-amd64.tar.gz
wget https://github.com/etcd-io/etcd/releases/download/v3.3.10/etcd-v3.3.10-linux-amd64.tar.gz
wget https://github.com/coreos/flannel/releases/download/v0.10.0/flannel-v0.10.0-linux-amd64.tar.gz

wget https://pkg.cfssl.org/R1.2/cfssl_linux-amd64
wget https://pkg.cfssl.org/R1.2/cfssljson_linux-amd64
wget https://pkg.cfssl.org/R1.2/cfssl-certinfo_linux-amd64
chmod +x cfssl_linux-amd64 cfssljson_linux-amd64 cfssl-certinfo_linux-amd64
mv cfssl_linux-amd64 /usr/local/bin/cfssl
mv cfssljson_linux-amd64 /usr/local/bin/cfssljson
mv cfssl-certinfo_linux-amd64 /usr/bin/cfssl-certinfo
```



## Config

```bash
mkdir /k8s/etcd/{bin,cfg,ssl} -p
mkdir /k8s/kubernetes/{bin,cfg,ssl} -p

# etcd certs
cd /k8s/etcd/ssl/
echo '{"signing":{"default":{"expiry":"87600h"},"profiles":{"etcd":{"expiry":"87600h","usages":["signing","key encipherment","server auth","client auth"]}}}}' | tee ca-config.json | jq
echo '{"CN":"etcd CA","key":{"algo":"rsa","size":2048},"names":[{"C":"CN","L":"Beijing","ST":"Beijing"}]}' | tee ca-csr.json | jq
#echo '{"CN":"etcd","hosts":["10.0.3.99","10.0.3.41","10.0.3.44"],"key":{"algo":"rsa","size":2048},"names":[{"C":"CN","L":"Beijing","ST":"Beijing"}]}' | tee server-csr.json | jq
echo '{"CN":"etcd","hosts":["10.0.0.188"],"key":{"algo":"rsa","size":2048},"names":[{"C":"CN","L":"Beijing","ST":"Beijing"}]}' | tee server-csr.json | jq

cfssl gencert -initca ca-csr.json | cfssljson -bare ca 
cfssl gencert -ca=ca.pem -ca-key=ca-key.pem -config=ca-config.json -profile=etcd server-csr.json | cfssljson -bare server   

# k8s certs
cd /k8s/kubernetes/ssl
echo '{"signing":{"default":{"expiry":"87600h"},"profiles":{"kubernetes":{"expiry":"87600h","usages":["signing","key encipherment","server auth","client auth"]}}}}' | tee ca-config.json | jq
echo '{"CN":"kubernetes","key":{"algo":"rsa","size":2048},"names":[{"C":"CN","L":"Beijing","ST":"Beijing","O":"k8s","OU":"System"}]}' | tee ca-csr.json | jq
#echo '{"CN":"kubernetes","hosts":["10.254.0.1","127.0.0.1","10.0.3.99","10.0.3.41","10.0.3.44","kubernetes","kubernetes.default","kubernetes.default.svc","kubernetes.default.svc.cluster","kubernetes.default.svc.cluster.local"],"key":{"algo":"rsa","size":2048},"names":[{"C":"CN","L":"Beijing","ST":"Beijing","O":"k8s","OU":"System"}]}' | tee server-csr.json | jq
echo '{"CN":"kubernetes","hosts":["10.254.0.1","127.0.0.1","10.0.0.188","kubernetes","kubernetes.default","kubernetes.default.svc","kubernetes.default.svc.cluster","kubernetes.default.svc.cluster.local"],"key":{"algo":"rsa","size":2048},"names":[{"C":"CN","L":"Beijing","ST":"Beijing","O":"k8s","OU":"System"}]}' | tee server-csr.json | jq
echo '{"CN":"system:kube-proxy","hosts":[],"key":{"algo":"rsa","size":2048},"names":[{"C":"CN","L":"Beijing","ST":"Beijing","O":"k8s","OU":"System"}]}' | tee kube-proxy-csr.json | jq

cfssl gencert -initca ca-csr.json | cfssljson -bare ca -
cfssl gencert -ca=ca.pem -ca-key=ca-key.pem -config=ca-config.json -profile=kubernetes server-csr.json | cfssljson -bare server
cfssl gencert -ca=ca.pem -ca-key=ca-key.pem -config=ca-config.json -profile=kubernetes kube-proxy-csr.json | cfssljson -bare kube-proxy
```



## Deploy Etcd

```bash
tar -xvf etcd-v3.3.10-linux-amd64.tar.gz
cd etcd-v3.3.10-linux-amd64/
cp etcd etcdctl /k8s/etcd/bin/
# 删除注释
vim /k8s/etcd/cfg/etcd.conf 
# 原文档缺少参数 ETCD_INITIAL_ADVERTISE_PEER_URLS
vim /usr/lib/systemd/system/etcd.service 
# 创建 working dir
mkdir -p /data1/etcd

systemctl daemon-reload
systemctl enable etcd
systemctl start etcd

#/k8s/etcd/bin/etcdctl --ca-file=/k8s/etcd/ssl/ca.pem --cert-file=/k8s/etcd/ssl/server.pem --key-file=/k8s/etcd/ssl/server-key.pem --endpoints="https://10.0.3.99:2379,https://10.0.3.41:2379,https://10.0.3.44:2379" cluster-health
/k8s/etcd/bin/etcdctl --ca-file=/k8s/etcd/ssl/ca.pem --cert-file=/k8s/etcd/ssl/server.pem --key-file=/k8s/etcd/ssl/server-key.pem --endpoints="https://10.0.0.188:2379" cluster-health
```



## Deploy K8s Control Plane

```bash
tar -zxvf kubernetes-server-linux-amd64.tar.gz 
cd kubernetes/server/bin/
cp kube-scheduler kube-apiserver kube-controller-manager kubectl /k8s/kubernetes/bin/

head -c 16 /dev/urandom | od -An -t x | tr -d ' '  # TLS Bootstrapping Token
echo '08e0de89211cb24b2a96a6d9ba011773,kubelet-bootstrap,10001,"system:kubelet-bootstrap"' >  /k8s/kubernetes/cfg/token.csv 

# config apiserver
vim /k8s/kubernetes/cfg/kube-apiserver
vim /usr/lib/systemd/system/kube-apiserver.service
systemctl daemon-reload
systemctl enable kube-apiserver
systemctl start kube-apiserver
ps -ef | grep kube-apiserver
netstat -ntplu | grep kube-apiserve

# config scheduler
vim /k8s/kubernetes/cfg/kube-scheduler 
vim /usr/lib/systemd/system/kube-scheduler.service 
systemctl daemon-reload
systemctl enable kube-scheduler.service 
systemctl start kube-scheduler.service

# config controller-manager
vim /k8s/kubernetes/cfg/kube-controller-manager 
vim /usr/lib/systemd/system/kube-controller-manager.service 
systemctl daemon-reload
systemctl enable kube-controller-manager
systemctl start kube-controller-manager
systemctl daemon-reload
systemctl enable kube-controller-manager
systemctl start kube-controller-manager

/k8s/kubernetes/bin/kubectl get cs,node
```



## Deploy K8s Worker Node

```bash
# config docker
yum install yum-utils
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
yum list docker-ce --showduplicates | sort -r
#yum install docker-ce -y
yum install docker-ce-18.03.1.ce-1.el7.centos docker-ce-cli-18.03.1.ce-1.el7.centos containerd.io
systemctl start docker && systemctl enable docker

# config kubelet
tar zxvf kubernetes-node-linux-amd64.tar.gz
cd kubernetes/node/bin/
cp kube-proxy kubelet kubectl /k8s/kubernetes/bin/

vim /k8s/kubernetes/cfg/kubelet.config 
vim /k8s/kubernetes/cfg/kubelet
vim /usr/lib/systemd/system/kubelet.service

# config node certs
cd /k8s/kubernetes/ssl/
#scp *.pem node1:/k8s/kubernetes/ssl/
cp *.pem /k8s/kubernetes/ssl/

# config kubelet bootstrap kubeconfig
vim /k8s/kubernetes/cfg/environment.sh 
cd /k8s/kubernetes/cfg/
export PATH="/k8s/kubernetes/bin:$PATH"
sh environment.sh 

# master 授权 kubelet-bootstrap 请求
kubectl create clusterrolebinding kubelet-bootstrap \
--clusterrole=system:node-bootstrapper \
--user=kubelet-bootstrap

systemctl daemon-reload 
systemctl enable kubelet 
systemctl start kubelet

# master 允许 CSR 请求
#Master接受kubelet CSR请求 可以手动或自动 approve CSR 请求。推荐使用自动的方式，因为从 v1.8 版本开始，可以自动轮转approve csr 后生成的证书
kubectl get csr
kubectl certificate approve node-csr-qZn2xaKey1osB-PaHAojr9TEkXjUeIzBQQkZLuG7MwA
kubectl get csr


## config kube-proxy
vim /k8s/kubernetes/cfg/kube-proxy
vim /usr/lib/systemd/system/kube-proxy.service 
systemctl daemon-reload 
systemctl enable kube-proxy 
systemctl start kube-proxy

kubectl create deployment nginx --image nginx
kubectl expose deployment nginx --port=80  --type="NodePort"
```



## Config Flanneld

略



## 附录

```bash
etcdmain: --initial-cluster has etcd01=https://10.0.0.188:2380 but missing from --initial-advertise-peer-urls=http://localhost:2380 ("http://localhost:2380"(resolved from "http://localhost:2380") != "https://10.0.0.188:2380"(resolved from "https://10.0.0.188:2380"))
.... --initial-advertise-peer-urls=\"${ETCD_INITIAL_ADVERTISE_PEER_URLS}\""
```



### scheduler 选项

–address：在 127.0.0.1:10251 端口接收 http /metrics 请求；
kube-scheduler 目前还不支持接收 https 请求； 
–kubeconfig：指定 kubeconfig 文件路径，kube-scheduler 使用它连接和验证 kube-apiserver； 
–leader-elect=true：集群运行模式，启用选举功能；被选为 leader 的节点负责处理工作，其它节点为阻塞状态；